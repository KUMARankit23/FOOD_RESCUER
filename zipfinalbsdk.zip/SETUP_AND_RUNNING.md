# FoodRescue-MAS: Setup and Running Guide

## Project Structure

```
FoodRescue-MAS/
├── schemas.py                    # Data contracts (Pydantic models)
├── tools.py                      # Deterministic tools (no LLM)
├── food_categories.py            # Food type classifications
├── rag_knowledge_base.py         # Safety knowledge base (15-30 chunks)
├── vyasa_generator.py            # Scenario generator with ground truth
├── agents.py                     # The four agents
│   ├── EklavyaIntakeAgent
│   ├── ArjunaMatchingAgent
│   ├── DronacharyyaSafetyAgent
│   └── ChanakyaLogisticsAgent
├── sutradhara_flow.py           # CrewAI Flow orchestrator
├── sukshmadarshini_observer.py  # Observability & evaluation layer
├── api.py                        # FastAPI backend (Sanjaya)
├── streamlit_dashboard.py        # Streamlit UI (Sanjaya)
├── test_runner.py               # Evaluation suite
├── requirements.txt             # Python dependencies
├── README.md                    # Project overview
└── SETUP_AND_RUNNING.md        # This file
```

## Installation

### 1. Prerequisites
- Python 3.9+
- pip or conda

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

Key packages:
- `crewai==0.45.0` - Multi-agent orchestration
- `pydantic==2.6.3` - Data validation & schemas
- `fastapi==0.109.0` - REST API backend
- `streamlit==1.32.0` - Web dashboard
- `faiss-cpu==1.7.4` - Vector similarity search
- `sentence-transformers==2.2.2` - Embeddings

### 3. Verify Installation

```bash
python -c "import crewai; import pydantic; import fastapi; print('✓ All dependencies installed')"
```

## Running the System

### Option 1: Quick Evaluation (Recommended First)

Run 40 scenarios and get metrics:

```bash
python test_runner.py
```

Output:
- 40 scenario runs through the complete flow
- Per-agent accuracy scores
- Summary metrics (latency, reliability, etc.)
- Detailed report saved to `evaluation_report.json`

### Option 2: Interactive API

Start the REST API server:

```bash
python api.py
```

Server runs on `http://localhost:8000`

Key endpoints:
- `POST /api/v1/reports` - Submit a surplus report
- `GET /api/v1/runs` - List all past runs
- `GET /api/v1/runs/{run_id}` - Get full run record
- `GET /api/v1/runs/{run_id}/trace` - Get agent trace
- `GET /api/v1/recipients` - List registered recipients
- `POST /api/v1/evaluate` - Run full 40-scenario evaluation
- `GET /api/v1/evaluate/summary` - Get metrics summary

Example request:
```bash
curl -X POST http://localhost:8000/api/v1/reports \
  -H "Content-Type: application/json" \
  -d '{
    "food_type": "vegetable biryani",
    "quantity": 60,
    "prep_time": "14:00",
    "temperature_c": 58.0,
    "location": "Hostel Mess B",
    "pickup_deadline": "20:00"
  }'
```

### Option 3: Web Dashboard (Streamlit)

Start the interactive dashboard:

```bash
streamlit run streamlit_dashboard.py
```

Opens at `http://localhost:8501`

Features:
- Submit surplus reports and see decisions
- View past runs and traces
- View performance metrics
- Test RAG retrieval directly

### Option 4: Programmatic Use

```python
from sutradhara_flow import SutradharaFlow
from sukshmadarshini_observer import SukshmadarshiniObserver

flow = SutradharaFlow()
observer = SukshmadarshiniObserver()

report = {
    "food_type": "vegetable biryani",
    "quantity": 60,
    "prep_time": "14:00",
    "temperature_c": 58.0,
    "location": "Hostel Mess B",
    "pickup_deadline": "20:00"
}

result = flow.execute_flow(report)
print(result["final_decision"])
```

## Key Files Explained

### 1. **Schemas** (`schemas.py`)
Pydantic models for data contracts:
- `SurplusReport` - Input from donors
- `ValidatedRecord` - Output from Eklavya
- `RankedMatches` - Output from Arjuna
- `SafetyDecision` - Output from Dronacharya
- `FinalDecision` - Output from Chanakya

### 2. **Tools** (`tools.py`)
Deterministic, no-LLM functions:
- `validate_report()` - Schema validation
- `lookup_location()` - Location verification
- `query_recipients()` - Find compatible recipients
- `distance_km()` - Calculate distance
- `time_temp_check()` - Safety check
- `schedule_pickup()` - Check availability

### 3. **Agents** (`agents.py`)
Four specialized agents:
- **Eklavya**: Validates reports, flags issues
- **Arjuna**: Ranks recipients by score
- **Dronacharya**: Assesses safety with RAG evidence
- **Chanakya**: Combines decisions into final plan

### 4. **Flow** (`sutradhara_flow.py`)
Orchestration logic:
- Creates run ID
- Routes through agents sequentially
- Validates schemas at each handoff
- Retries once on schema failure
- Records full trace

### 5. **Observer** (`sukshmadarshini_observer.py`)
Evaluation and observability:
- Records run traces
- Scores against ground truth
- Computes accuracy, latency, reliability
- Generates summary reports

### 6. **Vyasa** (`vyasa_generator.py`)
Scenario generator:
- Creates synthetic surplus reports
- ~25% are "awkward" edge cases
- Computes rule-based ground truth
- No hand-labeling, no LLM labeling

## Understanding the Flow

### Step 1: Intake (Eklavya)
```
Raw Report → validate_report() → lookup_location() → ValidatedRecord
```
Outputs: `status` (valid/needs_fix/rejected), `issues`, `missing_fields`

### Step 2: Matching (Arjuna)
```
ValidatedRecord → query_recipients() → distance_km() → estimate_demand()
→ Score & Rank → RankedMatches (top 3)
```
Outputs: Ranked list with scores and reasons

### Step 3: Safety (Dronacharya)
```
ValidatedRecord → RAG retrieve() → time_temp_check() → SafetyDecision
Evidence cited from knowledge base chunks
```
Outputs: Verdict (safe/unsafe/conditional) + evidence

### Step 4: Logistics (Chanakya)
```
ValidatedRecord + RankedMatches + SafetyDecision
→ schedule_pickup() → FinalDecision
```
Outputs: Action (dispatch/hold/discard/no_pickup) + plan

## Evaluation Metrics

### Accuracy
- **End-to-End**: Final decision vs ground truth
- **Per-Agent**: Each agent's output vs expected

### Performance
- **Latency**: Per-agent and total time (ms)
- **Retrieval Quality**: Relevance of RAG chunks

### Reliability
- **Schema Validation**: Failures and retries
- **Completion Rate**: % of runs that complete

## Definition of Done

The MVP is considered successful if:
1. ✓ 40 scenarios run without crash
2. ✓ ≥75% end-to-end accuracy
3. ✓ Every safety verdict cites a retrieved passage

Check with:
```bash
python test_runner.py
```

Look for the "Definition of Done Check" section in output.

## Troubleshooting

### Issue: Import errors
**Solution**: Ensure all dependencies installed: `pip install -r requirements.txt`

### Issue: FAISS not working
**Solution**: On Windows, use `faiss-cpu`. On Mac M1, may need special build.

### Issue: Low accuracy
**Solution**: Check Dronacharya's retrieval. Enable RAG debugging:
```python
from rag_knowledge_base import retrieve_passages
passages = retrieve_passages("your query", k=3)
```

### Issue: Slow evaluation
**Solution**: Normal—40 runs with LLM calls take ~2-5 minutes. Run in background or use simpler food items.

## Next Steps (Phase 2)

Future enhancements:
- Hierarchical architecture (Chanakya as manager)
- Event-driven execution
- LLM-as-Judge evaluation
- Architecture comparison study
- Multi-modal agent support

## References

- MVP Report: `README.md`
- Course: CSE3101 - Agentic AI (BMU, 2026-27)
- Tech Stack: CrewAI, FastAPI, Streamlit, FAISS

## Support

For issues or questions, refer to:
- `README.md` - Project overview
- `agents.py` - Agent logic
- `test_runner.py` - Evaluation example
- Inline code comments
