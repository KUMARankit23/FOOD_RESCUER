# 🔍 WHERE TO SEE: Decision | Recipient | Time | Duration

## ✅ Quick Answer

**All information is on the Operations Page:** http://localhost:3000/operations

---

## 📍 THREE PLACES TO SEE THE INFO

### **PLACE 1: Run History Table (Left Panel)**

**What to look for:**
```
┌──────────────┬──────────┬───────────┬───────┬──────────┬────────┐
│ Run ID       │Decision  │Recipient  │Time   │Duration  │Action  │
├──────────────┼──────────┼───────────┼───────┼──────────┼────────┤
│ 45278e28...  │MATCHED   │org_123    │14:15  │1500s     │ 👁️    │
│ 52ab9f4d...  │ACCEPTED  │org_456    │13:45  │900s      │ 👁️    │
│ 63cd1e7e...  │No Pickup │N/A        │13:20  │In Prog.  │ 👁️    │
└──────────────┴──────────┴───────────┴───────┴──────────┴────────┘
```

**Column Meanings:**
- **Run ID**: Unique identifier for the food submission
- **Decision**: AI agent's decision (MATCHED/ACCEPTED/NO PICKUP)
- **Recipient**: Organization assigned to receive food
- **Time**: When the food was submitted
- **Duration**: How long the operation took (in seconds)
- **Action**: Click 👁️ to view more details

---

### **PLACE 2: Details Panel (Right Side) - BEST VIEW**

When you click on a run, the Details panel opens showing:

```
┌────────────────────────────────────────┐
│ 📋 RUN DETAILS                         │
├────────────────────────────────────────┤
│                                        │
│ Run ID                                 │
│ ─────────────────────────────────────  │
│ 45278e287f2b4c2fa80e9d1234567890       │
│ (Complete ID, not truncated)           │
│                                        │
│ 🎯 Decision                            │
│ ─────────────────────────────────────  │
│ [MATCHED] ← Colored badge shows:      │
│                                        │
│  • MATCHED = Food matched with         │
│              recipient                 │
│  • ACCEPTED = Recipient accepted       │
│  • NO PICKUP = No recipient found      │
│                                        │
│ 👥 Recipient                           │
│ ─────────────────────────────────────  │
│ Recipient: org_123                     │
│ Food facility / Organization           │
│ (or "Waiting for assignment" if none)  │
│                                        │
│ ⏱️ Timeline                            │
│ ─────────────────────────────────────  │
│ Start Time: Nov 17, 2:15:30 PM         │
│ End Time: Nov 17, 2:40:30 PM           │
│ Duration: 1500 seconds (25 mins)       │
│                                        │
│ Status                                 │
│ ─────────────────────────────────────  │
│ ✅ Completed                           │
│ (or 🔄 In Progress if still running)  │
│                                        │
└────────────────────────────────────────┘
```

**This panel shows the MOST DETAILED information!**

---

### **PLACE 3: Agent Execution Timeline (Below Details)**

Shows step-by-step breakdown:

```
┌────────────────────────────────────────┐
│ Agent Execution Timeline               │
├────────────────────────────────────────┤
│                                        │
│ ✅ Location Verified         2:15:30 PM│
│    └─ Food location confirmed          │
│                                        │
│ ✅ Safety Checks Passed      2:16:45 PM│
│    └─ Temperature & prep OK            │
│                                        │
│ 🚗 Agent Dispatched           2:17:00 PM│
│    └─ Driver assigned (ETA 12 mins)   │
│                                        │
│ 📦 Pickup Complete            2:30:15 PM│
│    └─ Food collected                   │
│                                        │
│ 🚚 Delivery in Progress       2:35:45 PM│
│    └─ On the way to recipient          │
│                                        │
│ 🏁 Delivered                  2:40:30 PM│
│    └─ Food received                    │
│                                        │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100%      │
│ Total Duration: 25 minutes, 0 seconds  │
│                                        │
└────────────────────────────────────────┘
```

**This shows the EXACT TIME of each step!**

---

## 🎯 QUICK LOOKUP TABLE

| Question | Where to Find | What You'll See |
|----------|---------------|-----------------|
| **What was the decision?** | Details Panel → 🎯 Decision | MATCHED / ACCEPTED / NO PICKUP |
| **Who is the recipient?** | Details Panel → 👥 Recipient | Organization name/ID |
| **When was it submitted?** | Details Panel → ⏱️ Start Time | Nov 17, 2:15:30 PM |
| **When was it completed?** | Details Panel → ⏱️ End Time | Nov 17, 2:40:30 PM |
| **How long did it take?** | Details Panel → ⏱️ Duration | 1500 seconds (25 minutes) |
| **What was the timeline?** | Agent Timeline below | All 6 steps with exact times |
| **Quick overview?** | Table row | Decision, Recipient, Time, Duration |

---

## 🚀 HOW TO ACCESS NOW

1. **Open Operations Page**
   ```
   Go to: http://localhost:3000/operations
   ```

2. **See the table on the LEFT side**
   ```
   Columns: Run ID | Decision | Recipient | Time | Duration
   ```

3. **CLICK any run in the table**
   ```
   You'll see details appear on the RIGHT
   ```

4. **RIGHT PANEL opens showing:**
   ```
   📋 Run Details
   ├─ 🎯 Decision (AI's choice)
   ├─ 👥 Recipient (who gets food)
   ├─ ⏱️ Timeline (start/end/duration)
   └─ Status (completed or in progress)
   ```

5. **SCROLL DOWN to see**
   ```
   Agent Execution Timeline with all 6 steps + times
   ```

---

## 📊 UNDERSTANDING THE DATA

### **Decision Types**

| Decision | Meaning | Shows |
|----------|---------|-------|
| ✅ **MATCHED** | AI found a perfect recipient | Green badge |
| 🔵 **ACCEPTED** | Recipient agreed to take it | Blue badge |
| ⚠️ **NO PICKUP** | No recipient available | Gray/Warning badge |

### **Timeline Examples**

**Example 1: Quick delivery**
```
Start: 2:00 PM
End: 2:30 PM
Duration: 30 minutes
```

**Example 2: Slow delivery**
```
Start: 10:00 AM
End: 4:00 PM
Duration: 6 hours
```

**Example 3: In progress**
```
Start: 3:00 PM
End: Not yet (still running)
Duration: In Progress
```

---

## 💡 TIPS FOR READING THE DATA

1. **Look at the Details Panel FIRST**
   - Shows all information in one place
   - Most user-friendly view

2. **Use the Table for QUICK OVERVIEW**
   - See all runs at once
   - Compare multiple runs

3. **Check the Timeline for STEP DETAILS**
   - See exactly when each step happened
   - Track any delays

4. **Duration shows TOTAL TIME**
   - Automatically calculated
   - Shows in seconds or minutes

---

## 🎬 COMPLETE WORKFLOW EXAMPLE

**User submits food at 2:15 PM**

**Table shows:**
```
Run ID: 45278e2... | Decision: MATCHED | Recipient: org_123 | Time: 14:15 | Duration: 1500s
```

**Click on it → Details panel shows:**
```
🎯 Decision: ✅ MATCHED
👥 Recipient: Recipient: org_123
⏱️ Timeline:
   Start: Nov 17, 2:15:30 PM
   End: Nov 17, 2:40:30 PM
   Duration: 1500 seconds (25 minutes)
```

**Scroll down → Timeline shows:**
```
✅ Location Verified        2:15:30 PM
✅ Safety Checks Passed     2:16:45 PM
🚗 Agent Dispatched         2:17:00 PM
📦 Pickup Complete          2:30:15 PM
🚚 Delivery in Progress     2:35:45 PM
🏁 Delivered                2:40:30 PM
```

**Total: 25 minutes from submission to delivery** ✅

---

## ❓ TROUBLESHOOTING

**Q: I don't see any runs in the table**
A: Submit a new food report first on the Submit page

**Q: Why does it show "N/A" for some fields?**
A: The run hasn't progressed to that stage yet, or data isn't available

**Q: Where can I see if the food was actually delivered?**
A: Check the Agent Timeline - the last step shows if it's "Delivered"

**Q: Can I export this data?**
A: Currently it's displayed on screen - screenshots work well!

**Q: Why are times in 24-hour format?**
A: Check your browser's locale settings to change to 12-hour format

---

## 🎊 SUMMARY

All information you need is on the **Operations Page**:

✅ **Quick view**: Table shows Decision, Recipient, Time, Duration
✅ **Detailed view**: Details panel shows complete information
✅ **Step-by-step**: Timeline shows when each event happened

**Everything in one place!** 🚀

Go to http://localhost:3000/operations and try now!
