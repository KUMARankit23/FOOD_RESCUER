# 🚀 ANNASARTHI AI React - Quick Start (5 Minutes)

**TL;DR**: Get the React app running in 5 minutes

## Step 1: Open Two Terminals

### Terminal 1: Backend
```bash
cd "c:\Users\ankit\Downloads\food rescue mas"
python main.py
```
Wait for: `Application startup complete`

### Terminal 2: Frontend
```bash
cd "c:\Users\ankit\Downloads\food rescue mas\frontend_react"
npm install  # First time only, takes ~2 min
npm run dev
```
Wait for: `ready in XXX ms`

## Step 2: Open Browser

```
http://localhost:5173
```

## Step 3: Use the App

### 📊 Dashboard
- See real-time KPIs
- View activity charts
- Check recent operations

### 📝 Submit Food
- Fill the form
- Click Submit
- See it process through agents

### 🔍 Operations
- View all runs
- Click a run to see agent timeline
- Watch 4 agents execute sequentially

### 📈 Analytics
- Check system performance
- See agent accuracy metrics
- View success rate

### 🗺️ Map
- See dispatch locations
- View route statistics
- Check donor/recipient locations

### 📚 Knowledge Base
- Search food safety info
- Get RAG-powered results
- Browse featured guidelines

## That's It!

You now have:
- ✅ 6 fully functional pages
- ✅ Real-time data from backend
- ✅ Professional UI with warm colors
- ✅ 4 AI agents orchestrated by CrewAI
- ✅ Complete food rescue system

## Common Commands

| Command | Does |
|---------|------|
| `npm run dev` | Start development server |
| `npm run build` | Build for production |
| `npm run preview` | Preview production build |
| `F5` | Refresh page |
| `Ctrl+Shift+R` | Hard refresh (clear cache) |
| `F12` | Open Developer Tools |

## Verify Everything Works

1. ✅ Dashboard shows KPI cards
2. ✅ Submit Food form loads
3. ✅ Can type in form fields
4. ✅ Click Submit (see success message)
5. ✅ Go to Operations → See new run
6. ✅ Click run → See agent timeline
7. ✅ Go to Analytics → See charts
8. ✅ Go to Map → See dispatch data
9. ✅ Go to Knowledge → Can search

## Troubleshooting (30 seconds)

**Can't connect to backend?**
- Check Terminal 1: Is `python main.py` running?
- Verify: `http://localhost:8000/health` works

**Page is blank?**
- Open DevTools: F12 → Console
- Look for errors (red text)
- Refresh: Ctrl+Shift+R

**Form won't submit?**
- Check all fields are filled (red errors show)
- Check backend is running
- Check browser console for errors

## Stop the App

```
Terminal 1: Ctrl+C
Terminal 2: Ctrl+C
```

## Next Steps

1. **Explore the Code**
   - Open `frontend_react/src/` in editor
   - Read `README.md` for full documentation

2. **Test Features**
   - Follow `END_TO_END_TESTING.md` for complete walkthrough
   - Submit several reports
   - Verify agent execution

3. **Customize**
   - Colors in `tailwind.config.js`
   - Pages in `frontend_react/src/pages/`
   - Components in `frontend_react/src/components/`

4. **Deploy**
   - Run `npm run build` to create optimized bundle
   - Follow deployment guide in README.md

---

**Made with ❤️ by ANNASARTHI AI Development Team**
