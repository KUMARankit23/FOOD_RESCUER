# 🚀 Food Rescue MAS - Deployment Guide

## Quick Summary

Your Food Rescue system is complete with:
- ✅ React Frontend with interactive map location picker
- ✅ FastAPI Backend with CORS enabled
- ✅ Real-time agent chat for food rescue tracking
- ✅ Live tracking timeline with progress updates
- ✅ Full workflow: Submit Food → Agent Processes → Recipient Notified

---

## 📋 System Workflow

### DONOR (Food Submitter) Journey:
```
1. Submit Report Page
   ├─ Select food type
   ├─ Enter quantity & prep time
   ├─ Enter temperature
   ├─ PICK LOCATION on Interactive Map
   └─ Set pickup deadline
   
2. Receive Run ID & Confirmation
   ├─ Go to Operations Page
   ├─ Select your run
   └─ See real-time updates
   
3. Track via Agent Chat
   ├─ Receive live updates
   ├─ Ask agent questions
   └─ Monitor pickup & delivery
```

### RECIPIENT (Food Receiver) Journey:
```
1. Operations Page
   ├─ View available food rescues
   └─ Click on any run
   
2. Live Tracking Shows:
   ├─ Location verified
   ├─ Safety checks passed
   ├─ Agent dispatched (ETA)
   ├─ Food pickup status
   ├─ En route updates
   └─ Delivery confirmed
   
3. Agent Chat Updates
   ├─ Real-time messages
   ├─ Status notifications
   └─ Estimated arrival times
```

---

## 🖥️ LOCAL SETUP (Current)

### Currently Running:
```
Frontend: http://localhost:3000 (React + Vite)
Backend:  http://localhost:8000 (FastAPI)
API Docs: http://localhost:8000/docs (Swagger)
```

### To Start Locally:
```bash
# Terminal 1: Start Backend
cd "c:\Users\ankit\Downloads\food rescue mas"
python api.py

# Terminal 2: Start Frontend
cd "c:\Users\ankit\Downloads\food rescue mas\frontend_react"
npm run dev
```

---

## ☁️ DEPLOYMENT OPTIONS

### Option 1: Railway.app (Recommended - 5 min setup)
**Best for**: Quick production deployment

```bash
# 1. Install Railway CLI
npm install -g @railway/cli

# 2. Login
railway login

# 3. Create new project
railway init

# 4. Configure services
# Railway will auto-detect python and node
```

**Environment Variables Needed:**
```
BACKEND_PORT=8000
FRONTEND_PORT=3000
DATABASE_URL=your_db_url (optional)
```

### Option 2: Heroku (Classic)
**Best for**: Simple deployment with free tier

```bash
# 1. Install Heroku CLI
# 2. Login
heroku login

# 3. Create app
heroku create your-app-name

# 4. Push code
git push heroku main
```

### Option 3: Render.com (Free Tier Available)
**Best for**: Static site hosting + separate backend

```
Frontend: Deploy via GitHub
Backend: Use Web Service (free tier)
```

### Option 4: Docker + AWS/DigitalOcean/Linode
**Best for**: Production-grade deployment

```dockerfile
# Create Dockerfile for backend
FROM python:3.10
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "api.py"]
```

---

## 📦 PRODUCTION DEPLOYMENT CHECKLIST

### Backend (api.py)
- [ ] Remove localhost-only CORS origins
- [ ] Add production domain to CORS
- [ ] Enable HTTPS
- [ ] Set environment variables
- [ ] Add database persistence (if using)
- [ ] Set up logging

### Frontend (React)
- [ ] Build production bundle: `npm run build`
- [ ] Set backend URL to production API
- [ ] Enable analytics
- [ ] Test all pages on production domain
- [ ] Verify map API keys (if needed)

### Security
- [ ] Hide API keys in environment variables
- [ ] Enable CORS only for your domain
- [ ] Use HTTPS everywhere
- [ ] Add rate limiting
- [ ] Input validation on all forms

---

## 🔗 CONNECTION CONFIGURATION

### Current (Local)
**Frontend → Backend:** `http://localhost:8000`

### Production Example
**Frontend → Backend:** `https://api.example.com`

### Update in Code:
```javascript
// frontend_react/src/services/api.js
const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000'
```

---

## 🗺️ FEATURES READY FOR DEPLOYMENT

✅ **Submit Report with Interactive Map**
- Click to select location
- Search locations by name
- Use current GPS location
- Real-time coordinates

✅ **Live Tracking Dashboard**
- 6-step progress timeline
- Real-time status updates
- Overall progress percentage
- Estimated times

✅ **Agent Chat Communication**
- Real-time agent messages
- User can ask questions
- Automatic status updates
- Timestamp tracking

✅ **Operations Management**
- Run history table
- Detailed run information
- Full agent execution trace
- Timeline visualization

---

## 📊 API ENDPOINTS AVAILABLE

```
POST   /api/v1/reports           - Submit food report
GET    /api/v1/runs              - List all runs
GET    /api/v1/runs/{run_id}     - Get specific run
GET    /api/v1/runs/{run_id}/trace - Get agent trace
GET    /api/v1/recipients        - List recipients
GET    /health                   - Health check
```

---

## 🎯 NEXT STEPS FOR DEPLOYMENT

1. **Choose Platform** (Railway recommended for speed)
2. **Set Up Environment Variables**
3. **Configure CORS** with production domain
4. **Build Frontend** (`npm run build`)
5. **Deploy Backend** with Python runtime
6. **Deploy Frontend** as static site or Node service
7. **Test All Features** on production URL
8. **Set Up Monitoring** & error logging

---

## 🆘 TROUBLESHOOTING

**Issue**: `Connection refused on backend`
**Solution**: Check if backend is running on correct port

**Issue**: `CORS errors in console`
**Solution**: Update allowed origins in `api.py`

**Issue**: `Map not loading`
**Solution**: Verify Leaflet CSS is loaded (should be automatic)

**Issue**: `Agent chat not updating`
**Solution**: Check browser console for errors, refresh page

---

## 📞 CONTACT SUPPORT

For questions about deployment, check:
- Backend API Docs: `http://localhost:8000/docs`
- React DevTools in browser
- Server logs in terminal

**Current Status**: ✅ Ready for Production
