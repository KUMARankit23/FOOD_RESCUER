# ANNASARTHI AI - End-to-End Testing Guide

Complete walkthrough for testing the entire system from React frontend through CrewAI backend.

## System Architecture

```
┌─────────────────────┐
│   React Frontend    │ (http://localhost:5173)
│  (Vite, Tailwind)   │
└──────────┬──────────┘
           │ HTTP/REST API
           ↓
┌─────────────────────┐
│   FastAPI Backend   │ (http://localhost:8000)
│  (Python 3.10+)     │
└──────────┬──────────┘
           │ Agent Orchestration
           ↓
┌─────────────────────────────────────────┐
│        CrewAI Multi-Agent System         │
├─────────────────────────────────────────┤
│ • Eklavya (Intake Agent)                │
│ • Arjuna (Recipient Matching)           │
│ • Dronacharya (Food Safety)             │
│ • Chanakya (Coordinator)                │
└─────────────────────────────────────────┘
```

## Prerequisites

- Node.js 18+ installed
- Python 3.10+ installed
- Both backend and frontend dependencies installed
- ~10 minutes

## Pre-Test Checklist

```bash
# Backend
cd "c:\Users\ankit\Downloads\food rescue mas"
python main.py

# Frontend (in new terminal)
cd "c:\Users\ankit\Downloads\food rescue mas\frontend_react"
npm run dev
```

Wait for both to start:
- **Backend**: "Application startup complete" 
- **Frontend**: "ready in XXX ms"

## Test Scenario 1: Dashboard Loading

**Objective**: Verify dashboard loads with backend data

### Steps
1. Open browser to `http://localhost:5173`
2. Dashboard page should load automatically
3. Observe the following:

   ✅ **Expected Results**
   - KPI cards visible (Total Operations, Dispatched, On Hold, Success Rate)
   - Activity chart loads (even if empty)
   - Decision distribution pie chart
   - Recent operations list visible
   - All 6 navigation items in sidebar

   ✅ **Visual Check**
   - Warm color palette evident (cream background, green primary)
   - Smooth animations on page load
   - Responsive layout (no horizontal scroll)

### Data to Check
- Total Operations: Should be 0 initially (or count of previous runs)
- Success Rate: Displays percentage correctly
- Charts: Display without errors even with no data

---

## Test Scenario 2: Submit Food Report

**Objective**: Create a food report and trigger agent orchestration

### Steps

1. **Navigate to Submit Food**
   - Click "Submit Food" in sidebar
   - Form should load with all fields

2. **Fill Form** (Required fields in validation schema)
   
   **Food Details Section:**
   ```
   Food Type:        "Vegetable Biryani"
   Quantity:         50
   Prep Time:        "Fresh"
   ```

   **Safety Section:**
   ```
   Temperature:      25 (°C)
   ```

   **Location & Timing:**
   ```
   Pickup Location:  "Hostel Mess A"
   Pickup Deadline:  2024-11-20 18:30
   ```

3. **Validation Testing**
   - Remove Food Type → Should show error
   - Enter negative Quantity → Should show error
   - Enter temperature 150°C → Should show error
   - Errors should appear in red below fields

4. **Submit Report**
   - Click "Submit Report" button
   - Button should show loading state
   - Observe the following:

   ✅ **Expected Results**
   - Success message appears: "Report submitted successfully! Redirecting..."
   - After ~2 seconds, redirects to Operations page
   - New run appears in history

### Backend Verification
Check backend console, should see:
```
Food safety check completed...
Agent timeline: Eklavya → Arjuna → Dronacharya → Chanakya
Final decision: [DISPATCH|HOLD|DISCARD|NO_PICKUP]
```

---

## Test Scenario 3: View Operation Details

**Objective**: Inspect agent execution trace for submitted report

### Steps

1. **On Operations Page**
   - Should see recent run in "Run History" table
   - Columns: Run ID, Decision, Recipient, Time, Duration, Action

2. **Select Run**
   - Click eye icon on recent run
   - Right panel should populate with:
     ```
     Run ID: [UUID]
     Decision: [Action]
     Recipient: [ID or N/A]
     Timestamp: [DateTime]
     Status: Completed
     ```

3. **View Agent Timeline**
   - Below table, "Agent Execution Timeline" section appears
   - Should show 4 agent boxes in vertical timeline:
     ```
     📥 Eklavya (Intake Agent)
       ├─ Processed food report
       └─ Duration: XXXms
     
     🎯 Arjuna (Recipient Matching)
       ├─ Matched with recipients
       └─ Duration: XXXms
     
     🔬 Dronacharya (Food Safety)
       ├─ Validated food safety
       └─ Duration: XXXms
     
     ⚙️  Chanakya (Coordinator)
       ├─ Made final decision
       └─ Duration: XXXms
     ```

4. **Timeline Verification**
   ✅ **Expected Results**
   - All 4 agents show in timeline
   - Each has green checkmark (completed)
   - Durations shown in milliseconds
   - Flow is logical: Intake → Matching → Safety → Coordinator

---

## Test Scenario 4: Analytics Dashboard

**Objective**: Verify performance metrics and charts

### Steps

1. **Navigate to Analytics**
   - Click "Analytics" in sidebar
   - Page loads with KPI cards and charts

2. **Check KPI Metrics**
   - Total Operations: Should match count from Dashboard
   - Successful Dispatches: Count of DISPATCH decisions
   - Avg Latency: Average time between start_time and end_time
   - System Accuracy: From evaluation summary (if available)

3. **Verify Charts**
   - **Operation Trend**: Line chart showing operations by day
   - **Agent Performance**: Bar chart with 4 agents
     ```
     Eklavya:      94% accuracy, 120ms latency
     Arjuna:       91% accuracy, 140ms latency
     Dronacharya:  97% accuracy, 100ms latency
     Chanakya:     95% accuracy, 130ms latency
     ```

4. **System Health Section**
   - ✅ Completed checklist visible
   - 📊 Metrics cards showing:
     - Total Runs
     - Dispatch Rate
     - Avg Response Time
     - System Uptime (99.8%)

---

## Test Scenario 5: Live Map Tracking

**Objective**: Test map data fetching and display

### Steps

1. **Navigate to Map**
   - Click "Live Map" in sidebar
   - Page loads

2. **Verify Metrics**
   - Active Dispatches: Should show count
   - Donor Locations: Count of all donors
   - Recipients: Count of all recipients
   - Total Routes: Calculated from dispatches

3. **Check Statistics Sidebar**
   - Avg Distance: Displayed in km
   - Avg Time: Displayed in minutes
   - Total Distance: Cumulative distance
   - Donor/Recipient lists: Expandable with location names

4. **Dispatch History Table**
   - Shows all dispatches from submitted reports
   - Columns: From location, To recipient, Quantity, Timestamp, Status
   - Clicking row expands details

   ✅ **Expected Results**
   - If DISPATCH decisions made, shows in table
   - Otherwise, shows "No dispatches available"

---

## Test Scenario 6: Knowledge Base Search

**Objective**: Test RAG-powered safety knowledge retrieval

### Steps

1. **Navigate to Knowledge Base**
   - Click "Knowledge Base" in sidebar
   - Search interface loads

2. **Suggested Search**
   - Click "Safe storage temperature" button
   - Automatically fills search and triggers search
   - Backend calls RAG retrieval endpoint
   - Results appear with relevance scores

3. **Manual Search**
   - Clear search field
   - Type: "How to identify spoiled food"
   - Press Enter or click Search
   - Observe results:

   ✅ **Expected Results**
   - Results show with titles and content
   - Relevance score displayed (e.g., "Relevance: 89%")
   - Source tags shown (e.g., "Food Safety Database")
   - 3-5 results returned

4. **Featured Guidelines**
   - If no search has been performed
   - Should show 2 cards:
     - "Food Safety Essentials" (4 bullet points)
     - "Storage Best Practices" (4 bullet points)

---

## Test Scenario 7: Real-Time Data Refresh

**Objective**: Verify auto-refresh on intervals

### Steps

1. **Dashboard to Operations Flow**
   - Submit 2-3 food reports quickly
   - Stay on Dashboard
   - Watch "Recent Operations" list
   
   ✅ **Expected**: List updates every 5 seconds with new runs

2. **Check Backend Update Frequency**
   - Open browser DevTools (F12)
   - Network tab
   - Filter by XHR requests
   - Submit a report
   - Observe API calls:
     - `POST /api/v1/reports` (immediate)
     - `GET /api/v1/runs` (every 5 seconds after)

3. **Map Auto-Refresh**
   - Navigate to Map page
   - Watch Network tab
   - Should see `GET /api/v1/map/tracking` every 10 seconds

---

## Test Scenario 8: Error Handling

**Objective**: Verify error states and recovery

### Steps

1. **Stop Backend**
   - Terminate backend with Ctrl+C
   - Frontend should remain responsive

2. **Attempt Action**
   - Click "Submit Food"
   - Try to submit a form
   - Should see error message:
     ```
     ✗ Failed to submit report
     Network error or server unavailable
     ```

3. **Recovery**
   - Restart backend: `python main.py`
   - Click refresh or try again
   - Should work normally

4. **Invalid Form Submission**
   - Leave required fields empty
   - Click Submit
   - Should show validation errors without calling backend

---

## Test Scenario 9: Responsive Design

**Objective**: Verify responsive layout

### Steps

1. **Desktop (1440px)**
   - Open DevTools (F12)
   - Disable device emulation
   - All layouts should be comfortable
   - Sidebar visible
   - Charts full-width

2. **Tablet (1024px)**
   - DevTools → Toggle device toolbar
   - Select iPad
   - Layout should adapt:
     - Charts might stack vertically
     - Forms single-column
     - Navigation intact

3. **Mobile (390px)**
   - DevTools → iPhone 12 Pro
   - Layout should be optimal:
     - Sidebar might collapse
     - Single column everything
     - Touch-friendly spacing

---

## Test Scenario 10: Navigation & Routing

**Objective**: Verify React Router functionality

### Steps

1. **All Routes**
   ```
   / → Dashboard ✅
   /submit → Submit Food ✅
   /operations → Operations ✅
   /analytics → Analytics ✅
   /map → Map ✅
   /knowledge → Knowledge Base ✅
   /nonexistent → 404 Page ✅
   ```

2. **Sidebar Navigation**
   - Click each item
   - Should navigate smoothly with page transition
   - URL bar updates correctly

3. **Direct URL Entry**
   - Type `http://localhost:5173/operations` in address bar
   - Should load Operations page directly (no 404)

4. **Back Button**
   - Navigate through pages
   - Browser back button should work
   - History preserved

---

## Performance Testing

### Metrics to Check

1. **Page Load Time**
   - Dashboard: Should load in < 2 seconds
   - Subsequent pages: < 1 second

2. **API Response Time**
   - `GET /api/v1/runs`: < 200ms
   - `POST /api/v1/reports`: < 5 seconds
   - `GET /api/v1/safety/retrieve`: < 3 seconds

3. **Network Requests**
   - Dashboard: ~5-8 requests
   - Submit page: ~3-5 requests
   - Operations: ~4-6 requests

### Check with DevTools

```
F12 → Network tab → Throttle to "Fast 3G"
All pages should still be usable
No indefinite spinners
Graceful degradation
```

---

## Data Validation Testing

### Report Submission Validation

| Field | Valid | Invalid | Error Message |
|-------|-------|---------|---------------|
| Food Type | "Vegetable Biryani" | "" | "Please select a food type" |
| Quantity | 50 | -5 | "Quantity must be at least 1" |
| Temperature | 25 | 200 | Should reject (validation schema) |
| Location | "Hostel Mess A" | "" | "Please select a location" |
| Deadline | "2024-11-20 18:30" | "" | "Please select a pickup deadline" |

### Test All Combinations

1. Submit empty form → All errors show
2. Submit partial form → Missing field errors show
3. Submit with invalid data → Specific errors show
4. Submit with valid data → Success

---

## API Contract Testing

### Verify Request/Response Formats

**1. Submit Report**
```
Request (POST /api/v1/reports):
{
  "food_type": "Vegetable Biryani",
  "quantity": 50,
  "prep_time": "Fresh",
  "temperature_c": 25.0,
  "location": "Hostel Mess A",
  "pickup_deadline": "2024-11-20T18:30:00"
}

Response (200 OK):
{
  "run_id": "uuid-string",
  "final_decision": {
    "action": "dispatch|hold|discard|no_pickup",
    "recipient_id": "optional-id",
    "recipient_name": "optional-name"
  }
}
```

**2. List Runs**
```
Request (GET /api/v1/runs):
None

Response (200 OK):
{
  "runs": [
    {
      "run_id": "uuid",
      "status": "completed",
      "decision_action": "dispatch",
      "recipient_id": "r1",
      "start_time": "2024-11-20T12:00:00",
      "end_time": "2024-11-20T12:00:05"
    }
  ]
}
```

### Contract Compliance

✅ All responses match expected schema
✅ Status codes correct (200, 404, 400, etc.)
✅ Error messages descriptive
✅ Timestamps in ISO format

---

## Summary Checklist

### Functionality
- [ ] Dashboard loads with data
- [ ] Can submit food report
- [ ] Agent timeline visible
- [ ] Operations update in real-time
- [ ] Analytics display metrics
- [ ] Map shows dispatch locations
- [ ] Knowledge base search works
- [ ] 404 page displays

### UI/UX
- [ ] Warm color palette applied
- [ ] Animations smooth
- [ ] Forms validate properly
- [ ] Error messages clear
- [ ] Loading states show
- [ ] Success messages display
- [ ] Sidebar collapses/expands
- [ ] Navigation works

### Responsiveness
- [ ] Desktop (1440px) optimal
- [ ] Tablet (1024px) readable
- [ ] Mobile (390px) usable
- [ ] No horizontal scrolling
- [ ] Touch-friendly on mobile

### Performance
- [ ] Dashboard < 2 seconds
- [ ] API responses < 5 seconds
- [ ] Smooth scrolling
- [ ] No lag with animations
- [ ] Network tab clean

### Integration
- [ ] Real backend data
- [ ] No hardcoded mock data
- [ ] All endpoints working
- [ ] Error recovery functioning
- [ ] Auto-refresh working

### Accessibility
- [ ] Keyboard navigation works
- [ ] Focus states visible
- [ ] Color contrast sufficient
- [ ] Error messages clear
- [ ] Form labels present

---

## Troubleshooting

### Issue: "Cannot connect to backend"
**Solution**: 
```bash
# Terminal 1 (Backend)
python main.py

# Terminal 2 (Frontend)
npm run dev
```

### Issue: "404 API not found"
**Solution**: Check `.env` file has correct URL
```
VITE_API_BASE_URL=http://localhost:8000
```

### Issue: "Blank page with errors"
**Solution**: Open DevTools (F12), check console for errors

### Issue: "Data not updating"
**Solution**: Clear browser cache (Ctrl+Shift+Delete), refresh

---

## Success Criteria

✅ **Passed**: All scenarios complete, data flows end-to-end
✅ **Passed**: No console errors
✅ **Passed**: Performance acceptable
✅ **Passed**: Responsive layout working
✅ **Passed**: All pages accessible

## Sign-Off

After completing all test scenarios:

```
✅ Frontend: Ready for production
✅ Backend: Integration verified
✅ Data Flow: End-to-end working
✅ User Experience: Professional quality
✅ Performance: Within acceptable ranges

Status: READY FOR RELEASE
```

---

**Test Date**: [DATE]
**Tester**: [NAME]
**Environment**: Development
**Browser**: Chrome/Firefox/Safari
**System**: Windows/Mac/Linux

