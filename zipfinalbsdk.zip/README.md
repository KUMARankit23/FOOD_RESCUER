# FoodRescue-MAS: Multi-Agent System for Surplus Food Redistribution

<cite index="1-1,1-2">An agentic multi-agent system for surplus food redistribution. Eight figures from the epics, one mission: no plate left behind.</cite>

## Overview

<cite index="1-13,1-14,1-15,1-16">FoodRescue-MAS splits the redistribution chain among specialists. Each has one narrow job, its own tools, and a duty to show its reasoning. We named them after figures from the Mahabharata and Indian tradition. It is a storytelling device, but each name was chosen because the character genuinely resembles the work that agent does.</cite>

## The Cast

<cite index="1-25">Name | Role | Component
---|---|---
Vyasa | Composes every scenario and its correct answer | Scenario and ground-truth generator
Eklavya | Reads raw, untidy reports and works out what is valid | Intake and Validation Agent
Arjuna | Fixes on the best recipient, ignoring distractions | Demand and Matching Agent
Dronacharya | Judges safety against written standards and cites them | Safety and Compliance Agent (RAG)
Chanakya | Resolves conflicts and issues the final plan | Logistics Manager Agent
Sukshmadarshini | Notices every small event: timing, retries, errors | Observability and evaluation layer
Sanjaya | Tells the user what happened, live and in order | REST API and Streamlit UI
Sutradhara | Holds state and decides who acts next | CrewAI Flow</cite>

## Architecture

<cite index="1-26,1-27,1-28,1-29">The complete MVP architecture. Reports enter from Vyasa, move left to right through the four agents under Sutradhara's control, and leave through Sanjaya. Tools sit beneath each agent, data stores beneath the tools, and Sukshmadarshini watches everything.</cite>

## Quick Start

### Installation

```bash
pip install -r requirements.txt
```

### Run Test Evaluation

```bash
python test_runner.py
```

This will:
1. Generate 40 synthetic scenarios
2. Run each through the complete flow
3. Score against ground truth
4. Output summary metrics

### Start API Server

```bash
python api.py
```

The API runs on `http://localhost:8000`. Endpoints:
- `POST /api/v1/reports` - Submit a surplus report
- `GET /api/v1/runs` - List past runs
- `GET /api/v1/runs/{run_id}` - Full run record
- `GET /api/v1/recipients` - List recipients
- `POST /api/v1/evaluate` - Run evaluation suite

## Data Flow

<cite index="1-97,1-98,1-99,1-100,1-101,1-102">Hostel Mess B reports 60 portions of vegetable biryani, cooked at 1:00 pm, held at 58 deg C, with pickup possible until 8:00 pm. Eklavya confirms every field is present and the location exists. Arjuna pulls recipients who accept cooked vegetarian food and are open before 8 pm, then ranks three by capacity and distance, with a shelter 2.4 km away in the lead. Dronacharya retrieves the passages on cooked rice and hot holding: the food stayed above the safe temperature, but elapsed time is close to the limit, so the verdict is conditional with two cited chunks. Chanakya confirms the shelter can arrive inside the window, books a 6:15 pm slot and marks the action dispatch, with a note to serve within the hour. Sukshmadarshini stores the trace, and Vyasa's rule-based answer decides whether the run counts as correct.</cite>

## Key Components

### Schemas (`schemas.py`)
<cite index="1-90,1-91">Every arrow in the system is a Pydantic model. These are frozen before any agent is written.</cite>

### Tools (`tools.py`)
<cite index="1-41,1-42">Tools are plain Python functions with no LLM inside. That was a deliberate choice: when a result is wrong, we can tell within seconds whether the tool or the agent's reasoning is to blame.</cite>

### Agents
- **Eklavya**: <cite index="1-49,1-50">Reports arrive incomplete, oddly worded, sometimes contradictory. Goal: Turn a raw report into a clean, validated record.</cite>

- **Arjuna**: <cite index="1-58,1-59,1-60">His famous quality was focus. Given several recipients, he sees only the best one. Goal: Rank compatible recipients for the validated surplus.</cite>

- **Dronacharya**: <cite index="1-67,1-68,1-69">The teacher who knew the rules and taught them. He gives no opinions; he points to the text. Goal: Decide whether the food is safe to redistribute, and prove why.</cite>

- **Chanakya**: <cite index="1-77,1-78">His craft was making competing interests fit into one workable plan. Goal: Combine the top match and the safety verdict into a final decision and pickup plan.</cite>

### Orchestration (`sutradhara_flow.py`)
<cite index="1-36,1-37,1-38,1-39">The CrewAI Flow owns the run. It creates the run ID, passes state from one agent to the next, checks every output against its schema, retries once on a malformed result, and stops cleanly if the second attempt fails. Agents never call each other directly. Everything goes through the Flow, which is what makes runs reproducible and traceable.</cite>

### Observability (`sukshmadarshini_observer.py`)
<cite index="1-84,1-85,1-86">She is not an LLM agent. She is a logging and scoring layer that watches everything, because a system that cannot explain itself cannot be improved. For every run she records the run ID, the order of agents, start and end times per agent, tool calls with inputs and outputs, retrieved chunk IDs, schema failures, retries and the final decision.</cite>

## Evaluation Metrics

<cite index="1-87">Per-agent numbers matter most. A wrong final decision tells us little. A wrong decision traced to Dronacharya's retrieval tells us exactly what to fix.</cite>

Tracked metrics:
- End-to-end accuracy (final decision vs ground truth)
- Per-agent accuracy (validation, matching, safety)
- Retrieval quality (relevance of retrieved chunks)
- Latency (per-agent and total)
- Reliability (schema failures, retries, incomplete runs)

## Definition of Done

<cite index="1-113,1-114">Forty scenarios run without a crash, at least 75 percent match ground truth, and every safety verdict cites a retrieved passage.</cite>

## Technology Stack

<cite index="1-113">Agents and orchestration: CrewAI Agents and Flow (version pinned)
Language and API: Python, FastAPI, Pydantic
LLM: One API or local model, temperature 0.1
Retrieval: Sentence embeddings with FAISS
Data: SQLite, Pandas, NumPy
Interface: Streamlit
Logging: Structured JSON, one file per run
Tooling: Git, Kiro IDE for scaffolding</cite>

## References

- <cite index="1-1">FoodRescue-MAS MVP Report, Group 14</cite>
- <cite index="1-4">An academic prototype, not a food-safety certification tool.</cite>
